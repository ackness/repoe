审阅结论：**发现 1 项 P3，未发现有证据的 P1/P2。** 六份新原料的已观察字节链在限定范围内可以重放；它仍是 `unreviewed-acquisition-draft`，不构成来源认证或采用。三个 actor 均有明确候选，但目前不足以将现有 `mod_list` 宣称为已由独立来源迁移。

**Finding — P3：未支持的块注释可被当作普通 RHS 接受。**  
[词法扫描与字段解析](/Users/claw/.t3/worktrees/repoe/feat-native-actor-object-templates/RePoE/native_actor_templates.py:23) 只识别 `//` 和整行 `#` 注释；[字段分支](/Users/claw/.t3/worktrees/repoe/feat-native-actor-object-templates/RePoE/native_actor_templates.py:115) 对无大括号的 RHS 没有拒绝 `/* … */`。离线探针确认 `x = 1 /* misleading comment */` 和 `x = /* unknown syntax */` 均成功输出为 `literal`。这与[文档](/Users/claw/.t3/worktrees/repoe/feat-native-actor-object-templates/RePoE/docs/native_actor_templates.md:47)对不支持语法拒绝的表述不一致；当前原文仍保留、RHS 不执行，因此没有证据表明六份实际原料受到影响。最小修复是在字符串和已识别行注释之外检测未支持的 `/*` 并拒绝，加入普通 RHS、opaque RHS、引号内文本和 `//` 注释内文本的回归例子。

其余审阅范围内，重复字段保持 occurrence 顺序，未知 component 保留，opaque braced RHS 不执行；行、字段、directive、block 的实物重建复用 owner 的通过证据。父链的 missing/cycle/depth 有独立诊断，`nothing` 和追加后缀是本地路径约定；锁摘要、原料 pin、路径约束及 completion-last 发布代码未发现其他有证据的问题。未独立运行 Windows 发布路径或并发篡改测试。

**六份原料的字节链。** 核对了 F77 manifest 和 MonsterVarieties 表摘要、物理 column 8 与 `.ot`/`.otc` schema、三行的实际值；根路径来自该列，未从 variety alias 猜测。初始六候选 CLI 的退出码为 1：三个 OTC 缺失，CLI 没有成功 receipt。后续 wrapper 保存了 `locations()` 失败时的正向记录和缺失信息，标为诊断；其 framing 与既有固定 index framing 一致，不能称为完整 CLI 成功收据。

我在唯一允许的 review 目录运行了[小范围离线重放](/Users/claw/.t3/worktrees/pobr/design-independent-pobr-ecosystem/.cache/postmerge-20261101/actor-templates/review/replay.py)：直接核对六条 index 物理记录、路径哈希、bundle 名称和偏移，并用现有缓存与同一只读 decoder 解出六份 raw，逐一匹配 inventory、receipt 和磁盘字节。合计 6 OT、11,172 bytes；记录的新增传输为 6 ranges、151,512 body bytes、151,518 reserved bytes，index 定位为 warm/offline。三个 OTC 候选是选定 index 中未匹配，hash 命中也不证明权威大小写或排除碰撞。

重放确认的是**已观察基线的一致性**；原始 SHA 是首次观察值，不是独立预期 pin 或官方签名。语言、独立客户端 build 身份和权威路径大小写仍未知。未重审旧的 F77/91/10 CSD/12 locale/346 chunks 大闭包。

**三个现有 reader 候选：**

- **BearCompanion：暂不能实施独立接线。** row 1722 的 OT 顶层 `Stats.set_base_damage_taken_+% = -50`、DAT 的 7318/13893 及其余四个空组已核对。`Stats` 表存在 `base_damage_taken_+%`；固定 PoB2 的描述和旧 DTO `DamageTaken INC -50` 可作交叉核对。但仍需可引用的 `set_` 操作、Stats 作用域及父链与 DAT 优先级依据，才能将该 literal 映射为现有 DTO。reader 确实接受该 DTO；召唤物防御计算会读取数据，但当前汇总快照没有单独暴露 damage-taken/EHP 字段，因此应先明确实际目标输出。
- **SummonedRagingSpirit：最接近可接线，但尚缺适用性闭合。** 正确 variety 是 row 30；`Special_Mods` 5367 的唯一非空 stat 槽为 row 1908，最小值和最大值均为 40。固定 PoB2 的 stat 描述、skill stat map 和旧 DTO 一致地交叉指向 attack speed MORE；现有 reader 将 `Speed MORE 40, flags=1, keyword_flags=0, tags=[]` 转成 `AttackSpeed`，进入攻击动作速率和 DPS。还需独立依据说明 `Special_Mods` 对此召唤物及所选 active attack 的实际适用范围，并核对 OT/DAT 优先级。闭合后最小方案是将该单条来源投影到现有 `MinionModDef`，保留来源与未解释项，验证选定攻击的速率/DPS，以及不适用技能不受影响。
- **LivingLightning：暂不能从现有字面事实接线。** row 2309 的 OT 包含 `set_base_cannot_be_damaged=1`、`set_base_maximum_life_is_one=1` 和其他免疫/charge 字段；`DamageTaken MORE -100` 是旧模型表达，不是观察到的原始数值。reader 接受 `DamageTaken MORE`，但会跳过 `Life OVERRIDE` 和现有免疫 `FLAG`，因此八条旧记录不能作为已迁移的整体。需要先证明损伤禁止在现有静态输出中等价于该乘数，以及字段作用域和 precedence；对未读取的 flag 不应为迁移数量新增模型。

本次实际检查的 head：PoBR `3dca124527b0f076623355265a3cf4ed139e4ae6`；RePoE `d50918a3fc9c46ef381293e72a1ae284b4163a9b..cbf63d2854d7ea49b89838a1c8b3835bc46a9f86`，两者工作区干净。执行了上述离线重放、合成 RHS 探针、相关文件摘要及 diff 检查；复用了 owner 报告的 6 个合成测试、Ruff、OS 拒网 producer 和完整 span 重建结果，未自行重跑它们。未运行网络、安装、完整 producer、Cargo、WASM、浏览器或完整工作流；未修改产品、接受来源、发布或清理 source worktree。
