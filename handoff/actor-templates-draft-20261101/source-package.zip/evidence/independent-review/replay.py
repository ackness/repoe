import hashlib
import json
import os
from pathlib import Path
import struct
import sys

ROOT = Path('/Users/claw/.t3/worktrees/pobr/design-independent-pobr-ecosystem')
SRC = Path('/Users/claw/.t3/worktrees/repoe/feat-native-actor-object-templates/.cache/actor-templates-20261101')
sys.path.insert(0, str(ROOT / 'pipeline'))
import client_index as index

def digest(b):
    return hashlib.sha256(b).hexdigest()

def readj(path):
    return json.loads(path.read_bytes())

handoff = readj(SRC / 'handoff.json')
assert digest((SRC / 'handoff.json').read_bytes()) == 'dd9ddf73e64a8d947a6f6ea61326c7412c00868d7d13764ab971ba1cd7def062'
for key in ['variety-resource-map.final.json', 'raw-resource-inventory.final.json', 'facts-final/manifest.json', 'facts-final/templates.json', 'facts-final/source-lock.json', 'decoder-identity.json', 'locate.py', 'acquire.py']:
    data = (SRC / key).read_bytes(); pin = handoff['artifacts'][key]
    assert (len(data), digest(data)) == (pin['bytes'], pin['sha256']), key

inventory = readj(SRC / 'raw-resource-inventory.final.json')
assert len(inventory) == 6
frame = readj(SRC / 'level-00-diagnostic/index-locations.json')['framing']
chunks = frame['decoded_chunks']; chunk_size = chunks[0]['bytes']
def span(start, length):
    result = bytearray()
    while length:
        n, offset = divmod(start, chunk_size)
        b = (SRC / 'index-chunks' / f'{n:03d}.bin').read_bytes()
        assert len(b) == chunks[n]['bytes'] and digest(b) == chunks[n]['sha256']
        take = min(length, len(b) - offset); assert take > 0
        result.extend(b[offset:offset+take]); start += take; length -= take
    return bytes(result)

# Read the bounded bundle-name table, and only the six requested physical file records.
prefix = span(0, frame['file_table_offset'])
pos = 0
count, = struct.unpack_from('<I', prefix, pos); pos += 4
bundles = []
for _ in range(count):
    size, = struct.unpack_from('<I', prefix, pos); pos += 4
    name = prefix[pos:pos+size].decode('ascii'); pos += size
    rawsize, = struct.unpack_from('<I', prefix, pos); pos += 4
    bundles.append((name, rawsize))
file_count, = struct.unpack_from('<I', prefix, pos); pos += 4
assert pos == len(prefix) and file_count == frame['file_count']

network = [0, 0, 0]
seen = set()
for level in range(3):
    proof = readj(SRC / f'level-{level:02d}-diagnostic/index-locations.json')
    selection_path = SRC / f'level-{level:02d}-diagnostic/selection.json'
    selection, selection_bytes = index.draft.load_selection(selection_path)
    receipt = readj(SRC / f'level-{level:02d}-raw/draft-receipt.json')
    prefetch = readj(SRC / f'level-{level:02d}-prefetch.json')
    assert proof['framing'] == frame
    assert proof['request_sha256'] == digest((SRC / f'level-{level:02d}-request.json').read_bytes())
    assert receipt['selection']['sha256'] == digest(selection_bytes)
    assert receipt['decoder'] == readj(SRC / 'decoder-identity.json')['current']
    assert receipt['mode'] == 'offline' and receipt['network']['requests'] == 0
    for i, k in enumerate(('requests', 'body_bytes', 'reserved_bytes')): network[i] += prefetch['network'][k]
    cache = index.client.RangeCache(SRC / 'ranges', selection)
    ranges = index.client.Ranges(cache, 'offline')
    decoder = index.client.ExternalDecoder('/Users/claw/codes/repoe/.venv/bin/python', '/Users/claw/codes/repoe/uv.lock', selection)
    assert decoder.receipt == receipt['decoder']
    observations = {r['path']: r for r in receipt['resources']}
    for path, rec in proof['matched'].items():
        assert path not in seen; seen.add(path)
        hashed, bidx, offset, length = struct.unpack('<QIII', span(frame['file_table_offset'] + rec['record_index']*20, 20))
        assert (hashed, bidx, offset, length) == (rec['path_hash'], rec['bundle_index'], rec['offset'], rec['length'])
        assert hashed == index.hash64(path.lower().encode('ascii'), frame['hash_seed'])
        assert bundles[bidx] == (rec['bundle_name'], rec['bundle_raw_bytes'])
        selected = selection['resources'][path]
        assert selected['bundle_url'].endswith('/Bundles2/' + rec['bundle_name'] + '.bundle.bin')
        assert (selected['uncompressed_offset'], selected['uncompressed_length']) == (offset, length)
        raw = index.client.Bundle(selected['bundle_url'], ranges, decoder).read(offset, length)
        entry = next(v for v in inventory if v['resource'] == path)
        obs = observations[path]
        assert raw == Path(entry['raw_path']).read_bytes()
        assert (len(raw), digest(raw)) == (entry['bytes'], entry['sha256']) == (obs['observed_bytes'], obs['observed_sha256'])
        print(path, len(raw), digest(raw), 'record', rec['record_index'])
    assert ranges.requests == 0
assert seen == {v['resource'] for v in inventory}
assert network == [6, 151512, 151518], network
print('OK physical records, six cache-only decoded bytes, receipt identity; network records', network)
