"""Read-through warm caches, then one bounded acquisition using existing primitives."""
import json
from pathlib import Path
import sys
import traceback

sys.dont_write_bytecode = True
from locate import HERE, P, index, sha, put

client = index.client
WARM = [
    P / '.cache/items-actors-source-proof/cache',
    P / '.cache/client-index-proof/cache',
    P / '.cache/client-sources-integrated/cache',
    Path('/Users/claw/codes/pobr/.cache/worktree-cleanup-2026-10-31/t3-a5d6ad86/cache/item-metadata-source-proof/cache'),
]

def main(level):
    selection_path = HERE / f'level-{level:02d}-diagnostic/selection.json'
    source, source_bytes = index.draft.load_selection(selection_path)
    selected = [json.loads(p.read_bytes()) for p in HERE.glob('level-*-diagnostic/selection.json')]
    inventory = {n: v for s in selected for n, v in s['resources'].items()}
    assert len(inventory) <= 64 and sum(v['uncompressed_length'] for v in inventory.values()) <= 4 * client.MIB
    prior = list(HERE.glob('level-*-prefetch.json'))
    spent = sum(json.loads(p.read_bytes())['network']['reserved_bytes'] for p in prior)
    assert spent <= 8 * client.MIB
    own = client.RangeCache(HERE / 'ranges', source)
    warm = [client.RangeCache(p, source) for p in WARM if p.is_dir()]
    imports = []

    class Overlay:
        def read(self, url, start, length):
            data = own.read(url, start, length)
            if data is not None:
                return data
            for cache in warm:
                data = cache.read(url, start, length)
                if data is not None:
                    for r in cache.used.values():
                        if r['url'] != url:
                            continue
                        record_path = cache.root / 'ranges' / sha(url.encode()) / f"{r['start']}-{r['start'] + r['length'] - 1}.json"
                        own.add(url, r['start'], cache.body(r), r['total'], r['etag'], r['provenance'])
                        imports.append({'source_record': str(record_path), 'source_record_sha256': sha(record_path.read_bytes()), 'record': r})
                    return own.read(url, start, length)
            return None

        def info(self, url):
            return own.info(url)

    decoder = client.ExternalDecoder('/Users/claw/codes/repoe/.venv/bin/python', '/Users/claw/codes/repoe/uv.lock', source)
    assert decoder.receipt == json.loads((HERE / 'decoder-identity.json').read_bytes())['current']
    offline = client.Ranges(Overlay(), 'offline')
    misses = []
    for name, record in source['resources'].items():
        try:
            bundle = client.Bundle(record['bundle_url'], offline, decoder)
            raw = bundle.read(record['uncompressed_offset'], record['uncompressed_length'])
            assert len(raw) == record['uncompressed_length']
        except ValueError as error:
            misses.append({'resource': name, 'error': str(error)})
    online = None
    error = None
    try:
        if misses:
            online = client.Ranges(own, 'online', 8 * client.MIB - spent)
            bundles = {}
            for name, record in source['resources'].items():
                url = record['bundle_url']
                if url not in bundles:
                    bundles[url] = client.Bundle(url, online, decoder)
                raw = bundles[url].read(record['uncompressed_offset'], record['uncompressed_length'])
                assert len(raw) == record['uncompressed_length']
    except Exception as exc:
        error = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
    finally:
        network = {'requests': online.requests if online else 0, 'body_bytes': online.downloaded if online else 0,
                   'reserved_bytes': online.reserved if online else 0, 'cumulative_reserved_before': spent,
                   'cumulative_budget_bytes': 8 * client.MIB}
        put(HERE / f'level-{level:02d}-prefetch.json', {'status': 'failed' if error else 'cached-for-offline-collection',
            'selection_path': str(selection_path), 'selection_sha256': sha(source_bytes),
            'offline_misses': misses, 'error': error, 'network': network, 'warm_imports': imports,
            'decoder': decoder.receipt, 'tools': index.tools(), 'driver_sha256': sha(Path(__file__).read_bytes()),
            'ranges': list(own.used.values())})
    if error:
        raise RuntimeError(error['message'])
    receipt = index.draft.collect(selection_path, HERE / 'ranges', HERE / f'level-{level:02d}-raw',
        Path('/Users/claw/codes/repoe/.venv/bin/python'), Path('/Users/claw/codes/repoe/uv.lock'), 'offline')
    print(json.dumps({'level': level, 'resources': receipt['resources'], 'network': network}))

if __name__ == '__main__':
    main(int(sys.argv[1]))
