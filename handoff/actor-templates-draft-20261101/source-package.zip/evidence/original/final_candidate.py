"""Rebind the unchanged selected payload to the reviewed parser source."""
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from RePoE import native_actor_templates as actor
HERE = Path(__file__).resolve().parent
lock = HERE / 'actor-source-lock.observed.json'
manifest = actor.create_candidate(source_lock=lock, source='actor-templates-0.5.5.5-draft', raw=HERE / 'raw', out=HERE / 'facts-final', expected_source_lock_sha256=actor.envelope._sha(lock.read_bytes()))
for name in ['templates.json', 'source-lock.json']:
    assert (HERE / 'facts-final' / name).read_bytes() == (HERE / 'facts' / name).read_bytes()
print(json.dumps({'summary': manifest['summary'], 'manifest_sha256': actor.envelope._sha((HERE / 'facts-final/manifest.json').read_bytes()), 'payloads_equal_initial_candidate': True}))
