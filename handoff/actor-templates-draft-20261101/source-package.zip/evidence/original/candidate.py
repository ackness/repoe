"""One real offline actor candidate and byte/span checks against acquired receipts."""
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from RePoE import native_actor_templates as actor

HERE = Path(__file__).resolve().parent
enc, sha = actor.envelope._json, actor.envelope._sha

def put(path, value):
    actor.envelope._publish  # Explicitly reuse only the producer's offline API below.
    with path.open('xb') as stream:
        stream.write(enc(value))

def main():
    lead = json.loads((HERE / 'lead-request.json').read_bytes())
    resources, acquisition = {}, []
    raw_root = HERE / 'raw'
    raw_root.mkdir()
    for level in range(3):
        directory = HERE / f'level-{level:02d}-raw'
        receipt_path = directory / 'draft-receipt.json'
        receipt_bytes = receipt_path.read_bytes()
        receipt = json.loads(receipt_bytes)
        acquisition.append({'kind': f'level-{level:02d}-draft-receipt', 'sha256': sha(receipt_bytes)})
        selection_bytes = (directory / 'source-selection.json').read_bytes()
        assert sha(selection_bytes) == receipt['selection']['sha256']
        locations = json.loads((HERE / f'level-{level:02d}-diagnostic/index-locations.json').read_bytes())
        for row in receipt['resources']:
            name = row['path']
            raw = (directory / name).read_bytes()
            assert len(raw) == row['observed_bytes'] == locations['matched'][name]['length']
            assert sha(raw) == row['observed_sha256']
            assert name not in resources
            resources[name] = {'bytes': len(raw), 'sha256': sha(raw)}
            target = raw_root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(raw)
    selected = {'kind': 'official-client-resource-candidate', **lead['target'],
        'acquisition': {'status': 'unreviewed-acquisition-draft', 'evidence': acquisition},
        'raw_pin_basis': 'observed-first-acquisition; no original expected raw pins supplied',
        'language': None, 'roots': [r['schema_declared_path_candidates'][0] for r in lead['rows']],
        'resources': resources}
    lock_path = HERE / 'actor-source-lock.observed.json'
    put(lock_path, {'schema_version': 1, 'sources': {'actor-templates-0.5.5.5-draft': selected}})
    manifest = actor.create_candidate(source_lock=lock_path, source='actor-templates-0.5.5.5-draft', raw=raw_root,
        out=HERE / 'facts', expected_source_lock_sha256=sha(lock_path.read_bytes()))
    doc = json.loads((HERE / 'facts/templates.json').read_bytes())
    checks = []
    for name, syntax in doc['files'].items():
        data = (raw_root / name).read_bytes()
        assert b'\xff\xfe' + ''.join(row['raw_text'] for row in syntax['lines']).encode('utf-16le') == data
        for entry in syntax['lines'] + syntax['fields'] + syntax['directives']:
            start, end = entry['byte_span']
            assert data[start:end].decode('utf-16le') == entry['raw_text']
        for block in syntax['blocks']:
            start, end = block['byte_span']
            assert sha(data[start:end]) == block['raw_slice_sha256']
        text = data[2:].decode('utf-16le')
        parents = re.findall(r'^extends "([^"\r\n]+)"\r?$', text, re.M)
        assert parents == [syntax['extends']['literal']]
        assignments = re.findall(r'^\s*([^\s={}]+)\s*=', text, re.M)
        assert assignments == [field['key'] for field in syntax['fields']]
        checks.append({'resource': name, **resources[name], 'physical_lines': len(syntax['lines']),
            'independent_assignment_keys_equal': True, 'all_line_field_directive_spans_equal': True,
            'all_block_slice_hashes_equal': True, 'raw_reconstructed_exactly': True})
    assert manifest['summary'] == {'files': 6, 'roots': 3, 'raw_bytes': 11172, 'blocks': 43,
                                  'fields': 104, 'opaque_rhs_fields': 9, 'unresolved_roots': 0}
    mappings = []
    for row in lead['rows']:
        root = row['schema_declared_path_candidates'][0]
        chain = doc['roots'][root]
        assert chain['status'] == 'literal-nothing-terminated'
        mappings.append({**row, 'located_root': root, **chain,
                         'root_spelling_basis': 'physical BaseMonsterTypeIndex literal + schema .ot; index hash matches case-insensitively'})
    put(HERE / 'variety-resource-map.json', {'schema': 'selected-actor-variety-resource-map/v1',
        'target': lead['target'], 'observed_identity': {'fixed_patch_url': 'https://patch-poe2.poecdn.com/0.5.5.5/',
        'realm': 'caller-declared international', 'independent_client_build_identity': None,
        'language': None, 'authoritative_path_case': None}, 'rows': mappings,
        'missing_candidates': json.loads((HERE / 'level-00-diagnostic/index-locations.json').read_bytes())['missing']})
    put(HERE / 'real-verification.json', {'schema': 'actor-template-real-verification/v1',
        'status': 'passed', 'network': 'OS denied for candidate export and verification',
        'driver_sha256': sha(Path(__file__).read_bytes()), 'summary': manifest['summary'], 'resources': checks,
        'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in (HERE / 'facts').iterdir()}})
    print(json.dumps({'summary': manifest['summary'], 'manifest_sha256': sha((HERE / 'facts/manifest.json').read_bytes()),
                      'source_lock_sha256': sha(lock_path.read_bytes())}))

if __name__ == '__main__':
    main()
