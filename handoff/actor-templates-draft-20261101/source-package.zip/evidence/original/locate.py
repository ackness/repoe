"""Bounded diagnostics around the unchanged fixed-index reader; no network."""
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
P = Path('/Users/claw/.t3/worktrees/pobr/design-independent-pobr-ecosystem')
sys.path.insert(0, str(P / 'pipeline'))
import client_index as index

HERE = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()

def put(path, value):
    index.client.write_new(path, index.client.encoded(value))

def main(level):
    request_path = HERE / f'level-{level:02d}-request.json'
    request, request_bytes = index.load_request(request_path)
    url = 'https://patch-poe2.poecdn.com/0.5.5.5/Bundles2/_.index.bin'
    source = {'decoder': request['decoder'], 'resources': {'index': {'bundle_url': url}}}
    cache = index.client.RangeCache(P / '.cache/client-index-proof/cache', source)
    ranges = index.client.Ranges(cache, 'offline')
    decoder = index.client.ExternalDecoder('/Users/claw/codes/repoe/.venv/bin/python', '/Users/claw/codes/repoe/uv.lock', source)
    prior_path = P / '.cache/client-index-proof/discovery-c/index-locations.json'
    prior_bytes = prior_path.read_bytes()
    prior = json.loads(prior_bytes)['framing']
    expected_chunks = {c['chunk']: c for c in prior['decoded_chunks']}
    bundle = index.client.Bundle(url, ranges, decoder)

    class SavedChunks:
        # Cache only individually pinned decoded index chunks. No resource names
        # are enumerated; locations() remains the only index parser/hash search.
        size = bundle.size
        chunk_size = bundle.chunk_size

        def read(self, start, length):
            assert start % self.chunk_size == 0
            number = start // self.chunk_size
            pin = expected_chunks[number]
            assert pin['bytes'] == length
            path = HERE / 'index-chunks' / f'{number:03d}.bin'
            if path.exists():
                raw = index.client.read_file(path, self.chunk_size)
            else:
                raw = bundle.read(start, length)
                assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
                index.client.write_new(path, raw)
            assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
            return raw

    failure = None
    try:
        found, framing = index.locations(SavedChunks(), request['resources'])
    except ValueError as error:
        if not str(error).startswith('Paths not found in the selected index: '):
            raise
        # Preserve the original reader's positive records on its all-or-nothing
        # missing-path error. This is an incomplete discovery diagnostic, never
        # the reader's completion receipt. No parser or matching rules change.
        tb = error.__traceback__
        while tb and tb.tb_frame.f_code is not index.locations.__code__:
            tb = tb.tb_next
        state = tb.tb_frame.f_locals
        found = state['found']
        stream = state['stream']
        assert state['number'] == state['file_count']
        framing = {k: state[k] for k in ['bundle_count', 'file_count']}
        framing.update(file_table_offset=state['file_offset'], file_table_bytes=state['file_count'] * 20,
                       file_table_sha256=state['table_sha'].hexdigest(), directory_count=state['directories'],
                       first_directory_hash=state['root'], hash_seed=state['seed'],
                       parsed_prefix_bytes=stream.offset, parsed_prefix_sha256=stream.sha.hexdigest(),
                       decoded_chunks=stream.chunks)
        failure = str(error)
    assert framing == prior
    out = HERE / f'level-{level:02d}-diagnostic'
    out.mkdir()
    index.client.write_new(out / 'request.json', request_bytes)
    proof = {'schema': 'actor-selected-index-diagnostic/v1', 'status': 'unreviewed-index-locations',
             'production_ready': False, 'game_patch': request['game_patch'], 'realm': request['realm'],
             'index_url': url, 'request_sha256': sha(request_bytes), 'matched': found,
             'missing': [name for name in request['resources'] if name not in found],
             'reader_failure': failure, 'framing': framing,
             'prior_framing_path': str(prior_path), 'prior_framing_sha256': sha(prior_bytes),
             'path_spelling_authority': 'caller literal; case-insensitive hash match only'}
    put(out / 'index-locations.json', proof)
    proof_bytes = (out / 'index-locations.json').read_bytes()
    if found:
        selection = {'schema': index.draft.SELECTION_SCHEMA, 'game': request['game'], 'realm': request['realm'],
                     'game_patch': request['game_patch'], 'base_url': 'https://patch-poe2.poecdn.com/0.5.5.5/',
                     'decoder': request['decoder'], 'location_evidence': [{'id': 'diagnostic-index-records',
                     'reference': str(out / 'index-locations.json'), 'sha256': sha(proof_bytes)}], 'resources': {}}
        for name in request['resources']:
            if name not in found:
                continue
            r = found[name]
            selection['resources'][name] = {'bundle_url': selection['base_url'] + 'Bundles2/' + r['bundle_name'] + '.bundle.bin',
                'uncompressed_offset': r['offset'], 'uncompressed_length': r['length'],
                'location_evidence': ['diagnostic-index-records']}
        put(out / 'selection.json', selection)
        index.draft.load_selection(out / 'selection.json')
    put(out / 'diagnostic-receipt.json', {'schema': 'actor-selected-index-diagnostic-receipt/v1',
        'status': 'unreviewed-index-locations', 'production_ready': False, 'tools': index.tools(),
        'driver_sha256': sha(Path(__file__).read_bytes()), 'decoder': decoder.receipt,
        'network': {'requests': ranges.requests, 'body_bytes': ranges.downloaded, 'reserved_bytes': ranges.reserved},
        'ranges': list(cache.used.values()), 'decoded_index_chunk_input': str(HERE / 'index-chunks'),
        'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in out.iterdir()}})
    print(json.dumps({'level': level, 'matched': found, 'missing': proof['missing']}))

if __name__ == '__main__':
    main(int(sys.argv[1]))
