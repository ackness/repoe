"""Verify the existing candidate; exclude whole-line comments in the independent oracle."""
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from RePoE import native_actor_templates as actor

HERE = Path(__file__).resolve().parent
sha, enc = actor.envelope._sha, actor.envelope._json

def put(name, value):
    with (HERE / name).open('xb') as stream:
        stream.write(enc(value))

def main():
    manifest_path = HERE / 'facts-final/manifest.json'
    manifest = json.loads(manifest_path.read_bytes())
    for name, pin in manifest['files'].items():
        data = (HERE / 'facts-final' / name).read_bytes()
        assert len(data) == pin['bytes'] and sha(data) == pin['sha256']
    for name, pin in manifest['producer'].items():
        assert sha((ROOT / name).read_bytes()) == pin
    doc = json.loads((HERE / 'facts-final/templates.json').read_bytes())
    lock_bytes = (HERE / 'facts-final/source-lock.json').read_bytes()
    assert sha(lock_bytes) == manifest['source_identity']['source_lock_sha256']
    selected = json.loads(lock_bytes)['sources']['actor-templates-0.5.5.5-draft']
    assert selected['acquisition']['status'] == 'unreviewed-acquisition-draft'
    checks, inventory = [], []
    for name, syntax in doc['files'].items():
        data = (HERE / 'raw' / name).read_bytes()
        pin = selected['resources'][name]
        assert len(data) == pin['bytes'] and sha(data) == pin['sha256']
        assert b'\xff\xfe' + ''.join(row['raw_text'] for row in syntax['lines']).encode('utf-16le') == data
        for entry in syntax['lines'] + syntax['fields'] + syntax['directives']:
            start, end = entry['byte_span']
            assert data[start:end].decode('utf-16le') == entry['raw_text']
        for block in syntax['blocks']:
            start, end = block['byte_span']
            assert sha(data[start:end]) == block['raw_slice_sha256']
        text = data[2:].decode('utf-16le')
        parents = re.findall(r'^extends "([^"\r\n]+)"\r?$', text, re.M)
        assert parents == [syntax['extends']['literal']]
        # This checks every selected physical assignment key without using the
        # producer parser; it does not generalize to arbitrary embedded scripts.
        uncommented = '\n'.join(line for line in text.splitlines() if not line.lstrip().startswith(('//', '#')))
        assignments = re.findall(r'^\s*([^\s={}]+)\s*=', uncommented, re.M)
        assert assignments == [field['key'] for field in syntax['fields']]
        check = {'resource': name, **pin, 'physical_lines': len(syntax['lines']),
            'independent_assignment_keys_equal': True, 'all_line_field_directive_spans_equal': True,
            'all_block_slice_hashes_equal': True, 'raw_reconstructed_exactly': True}
        checks.append(check)
        occurrences = []
        for level in range(3):
            receipt_path = HERE / f'level-{level:02d}-raw/draft-receipt.json'
            receipt_bytes = receipt_path.read_bytes()
            for observation in json.loads(receipt_bytes)['resources']:
                if observation['path'] == name:
                    assert observation['observed_sha256'] == pin['sha256'] and observation['observed_bytes'] == pin['bytes']
                    proof_path = HERE / f'level-{level:02d}-diagnostic/index-locations.json'
                    proof_bytes = proof_path.read_bytes()
                    record = json.loads(proof_bytes)['matched'][name]
                    occurrences.append({'draft_receipt': {'path': str(receipt_path), 'bytes': len(receipt_bytes), 'sha256': sha(receipt_bytes)},
                        'index_proof': {'path': str(proof_path), 'bytes': len(proof_bytes), 'sha256': sha(proof_bytes)},
                        'physical_index_record': record, 'observation': observation})
        assert len(occurrences) == 1
        inventory.append({'resource': name, 'raw_path': str(HERE / 'raw' / name), **pin, 'extends': syntax['extends'],
                          'evidence': occurrences[0]})
    assert manifest['summary'] == {'files': 6, 'roots': 3, 'raw_bytes': 11172, 'blocks': 43,
                                  'fields': 104, 'opaque_rhs_fields': 9, 'unresolved_roots': 0}
    lead = json.loads((HERE / 'lead-request.json').read_bytes())
    mappings = []
    for row in lead['rows']:
        root = row['schema_declared_path_candidates'][0]
        chain = doc['roots'][root]
        assert chain['status'] == 'literal-nothing-terminated'
        mappings.append({**row, 'located_root': root, **chain,
                         'root_spelling_basis': 'physical BaseMonsterTypeIndex literal + schema .ot; case-insensitive index hash location'})
    put('variety-resource-map.final.json', {'schema': 'selected-actor-variety-resource-map/v1',
        'target': lead['target'], 'source_facts_manifest_sha256': lead['facts_manifest_sha256'], 'source_table_pin': lead['table'],
        'observed_identity': {'fixed_patch_url': 'https://patch-poe2.poecdn.com/0.5.5.5/',
        'realm': 'caller-declared international', 'independent_client_build_identity': None,
        'language': None, 'authoritative_path_case': None}, 'rows': mappings,
        'missing_candidates': json.loads((HERE / 'level-00-diagnostic/index-locations.json').read_bytes())['missing'],
        'edges': [{'resource': n, **f['extends']} for n, f in doc['files'].items()]})
    put('raw-resource-inventory.final.json', inventory)
    put('real-verification.final.json', {'schema': 'actor-template-real-verification/v1',
        'status': 'passed', 'network': 'OS denied for candidate export and verification',
        'initial_driver_failure': {'path': str(HERE / 'real-candidate.stderr'), 'sha256': sha((HERE / 'real-candidate.stderr').read_bytes()),
            'reason': 'Verification regex counted whole-line //flying comment; candidate publication succeeded before this assertion.'},
        'driver_sha256': sha(Path(__file__).read_bytes()), 'summary': manifest['summary'], 'resources': checks,
        'files': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in (HERE / 'facts-final').iterdir()}})
    print(json.dumps({'summary': manifest['summary'], 'manifest_sha256': sha(manifest_path.read_bytes()),
                      'source_lock_sha256': sha(lock_bytes)}))

if __name__ == '__main__':
    main()
