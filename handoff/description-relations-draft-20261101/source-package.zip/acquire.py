"""Two located tables only; read-only warm import; 4 MiB cumulative reservation."""
import json
import os
from pathlib import Path
import sys
import traceback
import urllib.error
import urllib.request

sys.dont_write_bytecode = True
from locate import HERE, index, client, sha, put


class RecordingResponse:
    def __init__(self, response, folder):
        self.response, self.folder = response, folder
        self.status, self.headers = response.status, response.headers
        self.reads = []
        client.write_new(folder / 'response-headers.eml', self.headers.as_bytes())
        put(folder / 'response.json', {'status': self.status, 'final_url': self.geturl(),
            'header_items': list(self.headers.raw_items()),
            'headers_serialization': 'HTTPMessage.as_bytes; not exact wire header bytes'})

    def geturl(self):
        return self.response.geturl()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        put(self.folder / 'reads.json', self.reads)
        return self.response.__exit__(*args)

    def read(self, count):
        raw = self.response.read(count)
        name = f'body-{len(self.reads):02d}.bin'
        client.write_new(self.folder / name, raw)
        self.reads.append({'requested_max_bytes': count, 'path': name, 'bytes': len(raw), 'sha256': sha(raw)})
        return raw


class RecordingOpener:
    def __init__(self):
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), client.NoRedirect())
        self.calls = 0

    def open(self, request, timeout):
        folder = HERE / 'http' / f'{self.calls:03d}'
        self.calls += 1
        put(folder / 'request.json', {'url': request.full_url, 'method': request.get_method(),
            'headers': request.header_items(), 'timeout_seconds': timeout})
        try:
            response = self.opener.open(request, timeout=timeout)
        except Exception as error:
            metadata = {'type': type(error).__name__, 'message': str(error)}
            if isinstance(error, urllib.error.HTTPError):
                metadata.update(status=error.code, final_url=error.geturl(), header_items=list(error.headers.raw_items()))
                client.write_new(folder / 'response-headers.eml', error.headers.as_bytes())
                # No unrequested error-body read. Reservation remains consumed.
                error.close()
            put(folder / 'failure.json', metadata)
            raise
        return RecordingResponse(response, folder)


def main():
    selection_path = HERE / 'selection.json'
    source, source_bytes = index.draft.load_selection(selection_path)
    assert 1 <= len(source['resources']) <= 3
    assert sum(r['uncompressed_length'] for r in source['resources'].values()) <= 4 * client.MIB
    prior = json.loads((HERE / 'decoder-identity.json').read_bytes())
    own = client.RangeCache(HERE / 'ranges', source)
    warm = client.RangeCache(Path(prior['warm_cache']), source)
    imports = {}

    class Overlay:
        def read(self, url, start, length):
            data = own.read(url, start, length)
            if data is not None:
                return data
            data = warm.read(url, start, length)
            if data is not None:
                for key, record in warm.used.items():
                    if record['url'] == url and key not in imports:
                        path = warm.root / 'ranges' / sha(url.encode()) / f"{record['start']}-{record['start'] + record['length'] - 1}.json"
                        raw = client.read_file(path, 8192)
                        own.add(url, record['start'], warm.body(record), record['total'], record['etag'], record['provenance'])
                        imports[key] = {'source_record': str(path), 'source_record_sha256': sha(raw), 'record': record}
                return own.read(url, start, length)
            return None

        def info(self, url):
            return own.info(url)

    decoder = client.ExternalDecoder('/Users/claw/codes/repoe/.venv/bin/python', '/Users/claw/codes/repoe/uv.lock', source)
    assert decoder.receipt == prior['current']
    offline = client.Ranges(Overlay(), 'offline')
    misses = []
    for name, record in source['resources'].items():
        try:
            bundle = client.Bundle(record['bundle_url'], offline, decoder)
            raw = bundle.read(record['uncompressed_offset'], record['uncompressed_length'])
            assert len(raw) == record['uncompressed_length']
        except ValueError as error:
            if not str(error).startswith('Offline cache miss:'):
                raise
            misses.append({'resource': name, 'error': str(error)})
    online = None
    error = None
    try:
        if misses:
            online = client.Ranges(own, 'online', 4 * client.MIB, 4 * client.MIB, RecordingOpener())
            bundles = {}
            for name, record in source['resources'].items():
                url = record['bundle_url']
                if url not in bundles:
                    bundles[url] = client.Bundle(url, online, decoder)
                raw = bundles[url].read(record['uncompressed_offset'], record['uncompressed_length'])
                assert len(raw) == record['uncompressed_length']
    except Exception as exc:
        error = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
    finally:
        network = {'requests': online.requests if online else 0, 'body_bytes': online.downloaded if online else 0,
            'reserved_bytes': online.reserved if online else 0, 'cumulative_budget_bytes': 4 * client.MIB,
            'per_request_cap_bytes': 4 * client.MIB, 'retries': 0, 'index_requests': 0}
        put(HERE / 'prefetch.json', {'status': 'failed-no-completion-receipt' if error else 'cached-for-offline-collection',
            'selection_sha256': sha(source_bytes), 'offline_misses': misses, 'error': error,
            'network': network, 'warm_imports': list(imports.values()), 'decoder': decoder.receipt,
            'tools': index.tools(), 'driver_sha256': sha(Path(__file__).read_bytes()),
            'ranges': list(own.used.values())})
    if error:
        raise RuntimeError(error['message'])
    receipt = index.draft.collect(selection_path, HERE / 'ranges', HERE / 'raw',
        Path('/Users/claw/codes/repoe/.venv/bin/python'), Path('/Users/claw/codes/repoe/uv.lock'), 'offline')
    print(json.dumps({'resources': receipt['resources'], 'network': network}, indent=2))


if __name__ == '__main__':
    os.environ['TMPDIR'] = str(HERE / 'tmp')
    main()
