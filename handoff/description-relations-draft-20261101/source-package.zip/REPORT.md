# 描述关系三表：有界来源证据交付

结论：本批推进了精确客户端资源与物理值证据，**未闭合任何 handler（0/13）**。三项声明命中两项，缺失一项；命中项是 0 行 support 表与仅有 generic key 0 的 reward visual 表。不能把 schema/spec 有名、成功解码或空表当作 PoE2 formatter 授权。

## 工作区与写域

- base / 最终 HEAD 均为 `d50918a3fc9c46ef381293e72a1ae284b4163a9b`；起始与最终 tracked clean，`git diff --check` 通过。
- 所有新文件仅在本 worktree `.cache/description-relations-20261101/`。无源码改动、源码 commit、checkout、代理、Herdr/Astra、外盘访问、安装/同步 .venv、编译/构建、push/PR、发布/采用、PoBR/global lock/CURRENT 修改。
- actor PR9 后续 merge 不改变本批 base；actor source 工作树和 canonical receipt-bound decoder 仅只读。

## 精确定位与原料

固定声明目录为 `Data/Balance/`；下表 table 均指精确 `<table>.datc64`，未猜目录、改名、枚举目录字符串或下载整 bundle。

| table | 精确固定 index 结果 | raw bytes | 实际 rows | 物理观察 |
| --- | --- | ---: | ---: | --- |
| IndexableSupportGems | 命中 Tiny.V6.1，record 4257032，raw offset 1965042 | 12 | 0 | 完整 raw 为 4 个零字节及 8 个 BB；无 Index、SupportGem 或 Name 值 |
| AfflictionRewardTypeVisuals | 命中 Tiny.V0.1，record 3964085，raw offset 1948044 | 98 | 1 | `_row=0; AfflictionRewardTypes=0; Id=DeliriumRewardGeneric; Name=Delirium` |
| IndexableNonActiveSupportGems | exact hash 未命中 | — | 未取得 | 保留缺失诊断，不制造空表；仅比较 lead，不是当前 13 scoped stats 的第三个 handler |

原始 SHA256（新观察，不是旧 expected pins）：

- `IndexableSupportGems`: `dcee8ef773abb4496aab2c0d8b33b72e66440e0ec922b96d779f87a5c4514505`。
- `AfflictionRewardTypeVisuals`: `aa10babef65f2aca1dc22f8397c22d4f9f241e1068262f5c6b89f36c5b991d9f`。

完整 raw 位于 `raw/Data/Balance/`，且 `raw-manifest.json` 再保留两份完整 hex、原始记录字节、物理行检查和 pins。`index-locations.json` 保存 exact caller spellings、path hash（另有精确 hex）、file/bundle records 的 byte offset/hex、缺失项及原 all-or-nothing reader 的失败诊断。

三资源 discovery 整体为 **incomplete-discovery-diagnostic**。随后 selection 明确只选两项已命中资源；`raw/draft-receipt.json` 的完成只适用于这两项。缺失项没有 raw、table、成功 receipt 或空占位。

## 采集范围、原响应和 decoder

新请求 6 次，HTTP body 合计 **157643 B**，含每请求 1 B overflow guard 的累计 reservation **157649 B / 4194304 B**；无重试。保存的响应 headers 序列化为 2008 B，body 加该序列化为 **159651 B**。未计量 TLS/TCP wire overhead；不是宣称精确 wire 字节数。请求范围、URL、headers、状态、ETag、原 body 和 pins 逐项见 `http-request-manifest.json` 与 `http/000..005/`。

| bundle | 请求 inclusive byte ranges | body bytes |
| --- | --- | ---: |
| Tiny.V0.1 | 0–59；60–3551；564635–640340 | 60 + 3492 + 75706 |
| Tiny.V6.1 | 0–59；60–3475；535380–610288 | 60 + 3416 + 74909 |

全部为 exact fixed HTTPS URL 的 HTTP 206；无重定向，后续同 bundle 请求绑定强 ETag。`http/*/response-headers.eml` 是 HTTPMessage 的序列化，`response.json` 另保留 raw header items；不把序列化说成逐字节 wire headers。HTTP body 是实际响应原字节，并与 immutable range records / blobs 逐字节核对。每个源 bundle 压缩后约 16 MB，本批只取上述 ranges，未下载整 bundle。

warm index 网络请求 **0**、本批 index 解码 **0 chunks**。只对既有 receipt-pinned decoded index 的 file-table extent（85337500 B）做三个精确 hash 搜索，并读取约 5.30 MB bundle metadata；本地读取并校验既有 346 个 cached decoded chunk 的 pin，未重解码、重采集这些 chunks，未重跑其旧闭包。固定 file-table SHA 是 `dc627eb7c5b619fc8e69d63e2665a145086a2cebe9f901f9d67080f62271615b`。原 framing、原 receipt 路径/pins 保留。只读指定 warm range root 的两项 bundle ranges 未命中，故新增上述 6 请求；没有写任何他人 cache。

真实 decoder 为 `/Users/claw/codes/repoe/.venv/bin/python`，Python 3.14.10、pyooz 0.0.8；模块 `ooz.abi3.so` SHA `eb8c34969b516e74a8912a70ac6cdc8e097e442292f67d087680be22f88560d0`，RECORD SHA `0c06d2a3d20fd61ba16b0deeb531f7a7d3d796a7d6450857f295450a963605d6`，canonical uv.lock SHA `6ac815b9e4263081b51e823a3f297f35a1c55c7fa57956d3bdd5d4a506c1c66b`。完整 identity SHA `73dd6bcebb9c67557780b4d4b676bf967360f5becda02d6b4bab136e5dc1fb40` 与 actor 及 original index receipt 完全一致；完整 METADATA/WHEEL/RECORD/lock pins 在 `decoder-identity.json`。没有创建/使用本 worktree .venv。

## 固定导出、真实 key 与关系候选

使用未修改的 `RePoE.native_tables` 通用 exporter，保留完整 typed columns、physical rows、null/0/重复/顺序/未知字段承载能力；只导出两个新 raw（合计 110 B），无 77 表重导出。

- 固定 schema revision `6034b071846ef61b39046ebdb59e6d5717179509`，schema SHA `50e098543345cf8323aeb294e2cfef1b6b44842faccf560ada935cebe22727df`，native specification SHA `c9417f03e2205ff649721c3dbf9620ee0c703bf905b3cf53469ce3eda86f1e25`。
- PyPoE `66d1d7442c5718260e1a8efd24989d22987e91af`；真实安装来源由 repository-owned `schema/pypoe-sources.json` 校验，native exporter 记录全部实际 source SHA，未使用不受信任 pyc。
- support schema 为 `Index i32 / SupportGem foreignrow -> SkillGems / Name string`，声明宽 28 B；空表实际无 row bytes，**不构成其非空列布局兼容证明**。Index 分布为空，min/max 未知（null），零 key 个数为 0、FK occurrence 为 0、join candidate 为 0。没有从 Name、SkillGems/SupportGems row ordinal 猜 Index 或偏移，也没有发明 level 关系。
- affliction schema 为 `AfflictionRewardTypes enumrow / Id string / Name string`，实际行宽精确 20 B。独立读取 raw signed i32 确认 key `0`（字节 `00000000`）；两项 UTF-16 指针与 exporter 全值一致。只有 key 0 一次，无 null、无重复；保留完整一行，不筛掉零。
- `AfflictionRewardTypes` 的 schema 是 `indexing:0, enumerators:[]`；只固定定义，不由 indexing/enumerator 顺序推 handler key base。`_row=0` 是这份 raw 的物理行号，与 enum raw key 的相等不建立一般转换规则。
- `map_endgame_affliction_reward_1..9` 的后缀不是已证 enum keys。没有 stat quantifier→raw key 合同、PoE2 handler 注册授权或 reward 分类映射；generic visual 行不闭合九项描述。
- 当前四个 `local_random_support_gem_index[/_1]` + `level[/_1]` 和九个 `map_endgame_affliction_reward_1..9` 共 **13 项仍未解决**。`relation-candidates.json` 记录逐组合同与真实分布。

只读对照既有 F77 manifest `050fcf93ce2cdc763d32fc9336516e25ee8791b0feb360bc811c835213712603` 的三个已有 decoded payload：SkillGems 1191 行、SupportGems 637 行、BaseItemTypes 5496 行。逐文件 bytes/SHA 与该 manifest 核对；不读/再解码它们的 raw，不验证全 F77 closure，不把其 names/ordinals 代替缺失 Index。其各 raw/table pins 与实际路径在 `f77-bounded-comparison.json`。

## 明确的社区反证与观察边界

实际固定 PyPoE `poe/file/translations.py` 2394–2426：`display_indexable_support` 和 `affliction_reward_type` 注册均处于 **`sequel == 1`** 守卫；NonActive 注册也同属 PoE1 守卫。固定 legacy `poe2.py` 1471–1486、23302–23320 有两个物理 spec；存在物理 spec 不等同 PoE2 formatter 已获语义依据。原 source SHA、trusted pin 与精确行摘录在 `community-evidence.json`。没有把旧固定 Python formatter 的 PoE1 策略移用到 PoE2。

本批始终 **source-acquisition-draft / unreviewed-acquisition-draft / partial-candidate / production_ready=false / not-adopted**。game_patch=0.5.5.5、realm=international、language=English 是固定路径和 exporter 的显式 target declaration；观察到了该官方 HTTPS CDN 路径、无 locale 子目录及英文 literal `Delirium`，没有独立认证客户端 build、patch、realm 或语言。新 raw_SHA 仅为此次观察与离线完整性冻结，不扩大旧 acceptance；`observed-source-lock.json` 只是本地 draft 输入，不修改既有锁。

复用已给出的 2026-11-01 22:01:43.493Z freshness 观察：189 B，SHA `4d7c3b2576f363d689f34a6cb70b4d77b8d1ea347fa039c17b1dff84d5d68e84`，端点公布 `0.5.5.5`。没有再 query；该观察不认证这些 raw 客户端身份。`observation-boundaries.json` 固定原 observation/response 路径与 pins。

## 交付与实跑

- `candidate/manifest.json`: 14811 B，SHA **`2ec3a9a9d53734114963ce2ab47972aabbae7c29c077bc46fd47f6f7d60bed8f`**。
- `candidate/tables.json`: 2325 B，SHA **`2b8237e919018c28bac6d4e5b9e08145cff4f134ebe657d51e56fd76f5b78c3b`**。
- draft source lock: 1686 B，SHA **`ca40e6366d721660d56e15f5f4bcc780103704d182bc72fea20b853c951a1c98`**。
- `handoff.json` 提供机器可读状态及主要 artifact pins；`artifact-pins.json` 是交付目录完整、相对路径 bytes/SHA 清单（不包含其自身及发送后的 transport receipt）。`COMMANDS.md`、driver、logs、child argv 固定实际命令。

实跑通过：精确 cached-index 搜索、receipt-bound decoder identity、两资源有界采集、原响应/range-cache 一致、既有 exporter、独立 binary row/count/key/string-pointer 检查、三份既有 F77 payload 的 pin 核对。只对新的 110 B raw 做一次小范围离线 exporter 重放，`tables.json / source-lock.json / manifest.json` 三项逐字节相同；未把空表判作语义成功。

实际未跑：无编译/构建/依赖安装/环境同步；无完整 unit/check suite 或 OS 拒网沙箱；无旧 335 MB 采集、F77 全导出/闭包复验、346 chunks 重解码；无 122 MB descriptions JSON 扫描；无 PoBR formatter/消费者实现、计算/BD/Web/浏览器验收；无远端 CI、push/PR、源码提交、发布/采用/CURRENT/global-lock 写入；无新 freshness query、独立来源/语言/patch/realm 认证或来源批准。

RePoE 默认只拥有来源事实。root 决定后续 PoBR 解释、消费者实现及验证；本批结果不足以启用两个 PoE2 handlers。后续若继续，应由 root 提供新的具体来源或量词合同；本批不扩表、不扩传输，不把同名 schema 重扫当作推进。
