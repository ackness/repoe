"""Observed-pin draft lock and existing native exporter; no source modification."""
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
from locate import HERE, ROOT, client, sha, put


def main():
    receipt_raw = (HERE / 'raw/draft-receipt.json').read_bytes()
    receipt = json.loads(receipt_raw)
    schema_source = json.loads((ROOT / 'schema/source.json').read_bytes())
    name = 'description-relations-0.5.5.5-observation-draft'
    selected = {
        'kind': 'official-client-resource-candidate', 'game': 'poe2',
        'game_patch': '0.5.5.5', 'realm': 'international', 'language': 'English',
        'acquisition': {'status': 'unreviewed-acquisition-draft', 'evidence': [
            {'kind': 'exact-index-hash-search-diagnostic', 'sha256': sha((HERE / 'index-locations.json').read_bytes())},
            {'kind': 'bounded-acquisition-draft-receipt', 'sha256': sha(receipt_raw)},
            {'kind': 'bounded-http-prefetch-observation', 'sha256': sha((HERE / 'prefetch.json').read_bytes())},
        ]},
        'decoder': {'repository': 'https://github.com/repoe-fork/pypoe',
            'revision': receipt['source_decoder_declaration']['revision'],
            'dat_schema_repository': schema_source['repository'],
            'dat_schema_revision': schema_source['revision'],
            'schema_sha256': sha((ROOT / 'schema/poe2.json').read_bytes())},
        'resources': {r['path']: {'bytes': r['observed_bytes'], 'sha256': r['observed_sha256']} for r in receipt['resources']},
    }
    # New local draft input pins only. No existing acceptance/lock is changed.
    lock = {'schema_version': 1, 'sources': {name: selected}}
    put(HERE / 'observed-source-lock.json', lock)
    lock_sha = sha((HERE / 'observed-source-lock.json').read_bytes())
    argv = ['/Users/claw/codes/repoe/.venv/bin/python', '-B', '-m', 'RePoE.native_tables',
        '--source-lock', str(HERE / 'observed-source-lock.json'),
        '--expected-source-lock-sha256', lock_sha, '--source', name,
        '--raw', str(HERE / 'raw'), '--out', str(HERE / 'candidate'), '--language', 'English']
    put(HERE / 'export-command.json', {'argv': argv, 'cwd': str(ROOT),
        'environment_overrides': {'TMPDIR': str(HERE / 'tmp'), 'PYTHONDONTWRITEBYTECODE': '1'},
        'raw_pin_semantics': 'New observations frozen for local decoding; not original expected pins or source acceptance.'})
    result = subprocess.run(argv, cwd=ROOT, env={**os.environ, 'TMPDIR': str(HERE / 'tmp'),
        'PYTHONDONTWRITEBYTECODE': '1'}, capture_output=True)
    client.write_new(HERE / 'logs/native-export.stdout', result.stdout)
    client.write_new(HERE / 'logs/native-export.stderr', result.stderr)
    put(HERE / 'export-result.json', {'returncode': result.returncode,
        'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr),
        'completion_manifest_present': (HERE / 'candidate/manifest.json').is_file()})
    print(result.stdout.decode(), end='')
    print(result.stderr.decode(), end='', file=sys.stderr)
    if result.returncode:
        raise SystemExit(result.returncode)
    tables = json.loads((HERE / 'candidate/tables.json').read_bytes())
    print(json.dumps(tables, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
