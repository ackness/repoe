# PoBR 数据迁移：共同进度与方向检查点

最后核对：2026-11-01 UTC。维护人：各域owner窄更新，root协调集成，监督协调发布。状态：剩余迁移与最终采用继续，活动数据未切换。

本文件是本机各 T3 会话共用的实时进度表；不是产品正确性的证明，也不是第二套架构设计。
本机固定路径：`/Users/claw/codes/pobr/.cache/t3-supervision/PROJECT-STATUS.md`。
架构依据为仓库 `docs/data-architecture.md`，当前优先级见 §13.1（commit `718191cf`，PR #190 已合并，merge `8ea1cb5b`）。
旧 checkout 的文档可能过时，先核对提交；可用 `git show 718191cf:docs/data-architecture.md` 读取。
完整证据索引保存在同目录 `state.json`；二者冲突时查原始证据和最新用户决定，不按文件大小或修改时间猜结论。

## 1. 用户目标与当前取舍

- 自主获取、维护游戏数据，能灵活适配版本和格式；RePoE 导出事实，翻译库维护语言，PoBR 统一消费。
- 用户最新要求：正式上线前迁移到最新官方游戏版本数据，并在发布前复核版本新鲜度。现有0.5.5.5候选保留作基线，不将旧数据改标签冒充最新；国际服/CDN精确身份先核对，国服不混用。
- 优先把新来源接回既有领域结构、完整 BuildData、计算核心、BD 码导入和玩家流程。保留已有计算能力。
- 不整体重写核心，不逐技能重建产品。算法/架构改动须有具体迁移冲突或错误、用户收益及现有路径不足的证据。
- 首阶段争取约 80% 的原有使用体验，再优化细节；这不是允许 20% 数值误差，也不是已测得的覆盖率。
- 已有采集、版本锁、原始事实、通用映射与审计修复继续复用。受限 Spark/三技能 profile 保留为验证工具，不继续作为迁移主线扩展。
- 可以明确保留尚未迁移域的固定社区输入；必须披露来源和适用版本，不虚称完全自主，不给跨补丁旧值重贴标签。
- 未支持信息保留原文/身份及诊断；不为增加通过率静默丢字段或把未知设为 0。

## 2. 当前事实：已完成与未完成分开

本节为root 2026-11-01最新状态；仅替代root旧状态，其它owner交接保持原始身份。

| 工作 | 当前状态 | 证据或边界 |
| --- | --- | --- |
| 活动数据与独立存储 | CURRENT=0.5.5.5；完整游戏/语言数据已迁出PoBR当前Git，按独立锁临时prepare | 现制作组合manifest73b2d77e/runtime dba0615e/bundle afc78a77已本地采用；初始2a03/d7ac验收另记原身份；RePoE与翻译库存储，PoBR仅代码/锁/自有规则；Git历史不改，无旧PoBR artifact回退 |
| 源码发布 | PoBR218/219/221及docs220/222、翻译库5、RePoE7/8均已合并，所有PR watches已停 | PoBR精确7e4d0c23完整CI8 jobs通过（41348105556），轻量也过；source仓checks通过；docs222仅所选文档门禁通过；未部署 |
| 独立语言生产 | producer629固定15输入产生9SC+audit，PoBR旧下载/合并生成器已退出 | 27896+140+2=28038，实际fresh remote generation逐字节匹配；TW/display单列；大verification不进入玩家包，0真实审核补译，SC观测身份仍unknown |
| buff/charm边界 | 旧ce8源对象已取到，15窗口局部一致但整体上游条件变化；13完整charm包仍有未知字段 | RePoEe3cabf9已合并为证据，guard_eligible=false，默认检查不放行；charm0/13效果迁移，12旧文本及Cleansing诊断保留 |
| 制作源与新消费者 | RePoE74c48815已修复语言默认P2并通过PR8合并；root39e6ec90接必需输入/八槽目录投影 | 33780内部FK/134272槽为source worker有界证据；root禁网组合89行→92条，业务值匹配，7源权重诊断和null stat -20/-20保留。历史旧执行身份仍unknown |
| 新制作组合 | manifest73b2d77e/runtime dba0615e/bundle afc78a77，只更新crafting来源元数据 | 独立artifact2c664da4已发布；fresh远端Git/禁网重放/默认固定CLI等价后本地采用。旧2a/d7目录保全；PoBR221精确7e4d轻量/完整CI已过并merge9dc；CI产物完整归档摘要及收据核验v2/2c/dba/afc，紧凑release仍9932/ec4，82虚拟文件 |
| 旧版回滚 | 独立game684d42ab/locale93d9e164恢复dcfc32c2/bundle6768c476，keep-current已验证 | 原回滚锁及metadata不改；旧golden不重贴当前target |
| Actor OT新原料 | RePoE cbf63d2审阅唯一P3由root b41b3e84修复，最终a933f61d；PR9精确CI过并merge3551dd30 | 6raw/11172B；独立artifact9f20e64c已发布，fresh远端62成员核验与OS拒网三输出逐字节恢复；来源仍draft，0个mod_list迁移 |
| 生命周期 | 原批及语言/charm/buff/review线程已settled并正常清理，证据保留 | crafting producer与review已settled262451/262457；canonical严格FFd509，source worktree正常移除，全部证据collected/crafting/保全 |

不以诊断数量或单一百分比替代来源、计算、UI、采用和发布的独立结论。禁止外盘不访问；只用T3 sol/terra。

## 3. 当前实施交付与验收

当前root HEAD `0d6fe696d21fcc8ed60b42ad93e7cb5aaa40f819` clean，与origin/master同treec8ec16d4；actor／新鲜度文档PR223（pub a78b3d66）已过所选文档CI41355112507并merge70cc6fcb；未推原design历史。PR221已merge9dc，文档PR222已merge0e6；本地正常合并两次master并保持同树，不推原design历史。16路径：必需RePoE crafting输入与v2组合、八槽regular-stat投影、构建收据、旧raw提取器退出、regen预检、回归及领域文档。完整check:workflows通过（新增输入预检的旧测试夹具已修正）；crafting7/build12/runtime-pack8通过；82相对文档链接和diff通过。没有新Rust/WASM/浏览器/远端CI或335MB/356重跑。原始实现/审阅证据保留于crafting-integration/；修正、远端获取、采用与CI状态以 `.cache/postmerge-20261101/crafting-final/REPORT.md` 和state.json为准。

下一步：RePoE actor PR9精确a933f61d/base d50918a3已过Verify41354637621并merge3551dd30，两个watch均停；独立审阅唯一P3 block-comment已由root b41b3e84修复，7定向测试/Ruff过；新facts4a208bef绑定修正producer，templatesda09bc6c/lock60f2be36同字节。独立artifact9f20e64c已发布并fresh远端62成员及OS禁网重放验明；这只恢复观察字节，不批准来源/语义。三root父链物理到Monster→nothing、三OTC缺失均保留；Bear=-50、Rage SpecialMod5367=40、LivingBoolean→旧数值仍缺set_/scope/precedence依据，0个mod_list迁移。生命周期已确认canonical严格FF355干净、owner/review settled266693/266699；source worktree继续留给两个活动reader，结束后专门线程再保全/清理；root意外离线创建的该处.venv也保全，原decoder未动。整体目标继续。

真实剩余：unique有序base/mod/roll/variant仍缺完整目标来源；9 socketables=5 compound+4 exact CSD，树39整节点+1variant保留；37 scoped=8owner+13handler+16ordinary，25诊断effectless=false。13 charm完整scope未知，不再重复raw导出；actor OT闭包/合并、召唤关系、部分技能scope/ClientStrings/geometry等分别保留。旧7 implicit惰性条目删除只是清理，不能虚称能力改善。官方discovery现已在22:01:43 UTC实际返回0.5.5.5，189B观察响应SHA4d7c3b25已存；这只说明当时端点公布版本，原13:34超时保留，不认证原料客户端身份，正式上线前仍复核。

只读actor语义线程 <t3-thread://v2/ce64fd3e-1463-4764-9139-4a80c2681391/mcp:launch:9fbc17c75351015868c2aaf20752d52e51da78999d946f28a199fcd6e9ff21b3> 已启动（sol/xhigh）；重点补Raging Special_Mods的实际适用和OT/DAT优先级，不新增模型／数据。source工作树先保留到该研究完成，再由既有生命周期线程处理。

新的描述关系来源线程 <t3-thread://v2/ce64fd3e-1463-4764-9139-4a80c2681391/mcp:launch:6b44fb20f26e6ebb1a686848f5febf0f250b66d478467bd191f57f34938b1331> 已启动（sol/xhigh），限固定schema声明的3个IndexableSupport/Affliction候选表、4MiB新传输，复用warm index/decoder。目标调查4+9个handler缺口；schema提示不等于客户端存在、索引基准或关系语义，尚无新绑定。
