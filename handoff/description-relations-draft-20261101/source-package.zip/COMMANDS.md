# Actual execution commands

Working directory: `/Users/claw/.t3/worktrees/repoe/feat-native-description-relation-tables`.
No installation, synchronization, native compilation, build, Git mutation, push or PR command was run.

The four acquisition/export/verification drivers below were actually executed once each. Their exact bytes are in `artifact-pins.json`; logs preserve stdout/stderr. `export-command.json` and `replay-command.json` preserve the exact child argv, source-lock pin, cwd and environment overrides.

```sh
git rev-parse HEAD
git status --short
cat /Users/claw/.codex/RTK.md
sed -n '1,240p' /Users/claw/codes/pobr/.cache/t3-supervision/PROJECT-STATUS.md
TMPDIR="$PWD/.cache/description-relations-20261101/tmp" /Users/claw/codes/repoe/.venv/bin/python -B .cache/description-relations-20261101/locate.py > .cache/description-relations-20261101/logs/locate.log 2>&1
TMPDIR="$PWD/.cache/description-relations-20261101/tmp" /Users/claw/codes/repoe/.venv/bin/python -B .cache/description-relations-20261101/acquire.py > .cache/description-relations-20261101/logs/acquire.log 2>&1
TMPDIR="$PWD/.cache/description-relations-20261101/tmp" /Users/claw/codes/repoe/.venv/bin/python -B .cache/description-relations-20261101/export.py > .cache/description-relations-20261101/logs/export.log 2>&1
TMPDIR="$PWD/.cache/description-relations-20261101/tmp" /Users/claw/codes/repoe/.venv/bin/python -B .cache/description-relations-20261101/verify.py > .cache/description-relations-20261101/logs/verify.log 2>&1
TMPDIR="$PWD/.cache/description-relations-20261101/tmp" /Users/claw/codes/repoe/.venv/bin/python -B .cache/description-relations-20261101/finalize.py
git diff --check
```

Additional read-only inspection used `rg --files`, `rg -n`, `cat`, `sed` and short Python `-B` scripts on the applicable repository files and the exact caller-provided actor / warm-cache / F77 / freshness paths. The initially literal `/Users/claw/codes/pobr/.cache/{plain-display-integration-20261101,postmerge-20261101}` paths were absent; the explicitly referenced PoBR maintainer checkout contains those exact caches and was used read-only. No filename variations or alternative CDN resources were queried.

No tracked AGENTS.md was present in this checkout or the checked local ancestor paths. The user-provided AGENTS instruction and referenced RTK.md apply; the current task explicitly forbids delegation/Herdr/Astra and overrides the older delegation preference. Source and PoBR ownership follow the user brief and shared status §§1–3.
