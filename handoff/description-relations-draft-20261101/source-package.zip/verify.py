"""Small offline replay, independent raw checks, and bounded F77 comparison."""
from collections import Counter
import importlib.metadata
import json
from pathlib import Path
import struct
import subprocess
import sys

sys.dont_write_bytecode = True
from locate import HERE, ROOT, P, client, sha, put


def pinned(path, pin, cap):
    raw = client.read_file(path, cap)
    assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256'], str(path)
    return raw


def main():
    manifest = json.loads((HERE / 'candidate/manifest.json').read_bytes())
    tables = json.loads(pinned(HERE / 'candidate/tables.json', manifest['files']['tables.json'], 65536))
    receipt_raw = (HERE / 'raw/draft-receipt.json').read_bytes()
    receipt = json.loads(receipt_raw)
    index_proof = json.loads((HERE / 'index-locations.json').read_bytes())
    assert len(index_proof['matched']) == 2 and len(index_proof['missing']) == 1
    assert set(tables) == {'IndexableSupportGems', 'AfflictionRewardTypeVisuals'}
    assert receipt['network']['requests'] == 0 and receipt['network']['body_bytes'] == 0
    raw_entries = {}
    for resource in receipt['resources']:
        pin = {'bytes': resource['observed_bytes'], 'sha256': resource['observed_sha256']}
        raw = pinned(HERE / 'raw' / resource['path'], pin, 4096)
        name = Path(resource['path']).stem
        table = tables[name]
        count = struct.unpack_from('<I', raw)[0]
        width = 28 if name == 'IndexableSupportGems' else 20
        boundary = 4 + width * count
        assert raw[boundary:boundary + 8] == b'\xbb' * 8
        assert count == len(table['rows'])
        assert table['validation']['schema_row_bytes'] == width
        assert table['validation']['warnings'] == []
        physical = []
        if name == 'IndexableSupportGems':
            assert raw == b'\0' * 4 + b'\xbb' * 8
            assert count == 0 and table['rows'] == []
        else:
            assert count == 1
            key, id_pointer, name_pointer = struct.unpack_from('<iQQ', raw, 4)

            def string(pointer):
                start = boundary + pointer
                end = start
                while raw[end:end + 4] != b'\0' * 4:
                    end += 2
                    assert end + 4 <= len(raw)
                return raw[start:end].decode('utf-16-le')

            values = {'AfflictionRewardTypes': key, 'Id': string(id_pointer), 'Name': string(name_pointer)}
            assert table['rows'] == [{'_row': 0, 'values': values}]
            assert key == 0
            physical = [{'row': 0, 'row_bytes_hex': raw[4:24].hex(), 'enum_i32_signed': key,
                'enum_i32_hex': raw[4:8].hex(), 'Id_pointer_u64': str(id_pointer),
                'Name_pointer_u64': str(name_pointer), 'values': values}]
        raw_entries[resource['path']] = {**pin, 'hash_semantics': 'observed raw; no original expected raw pin',
            'full_raw_hex': raw.hex(), 'row_count_u32': count, 'schema_row_bytes': width,
            'observed_row_bytes': table['validation']['actual_row_bytes'],
            'empty_table_cannot_validate_column_layout': count == 0,
            'physical_rows_independent_check': physical,
            'index_record': index_proof['matched'][resource['path']],
            'source_receipt_sha256': sha(receipt_raw)}
    put(HERE / 'raw-manifest.json', {'status': 'source-acquisition-draft', 'production_ready': False,
        'resources': raw_entries, 'missing': index_proof['missing'],
        'declared_three_resource_selection_complete': False,
        'located_subset_collection_complete': True,
        'all_or_nothing': 'Three-resource discovery incomplete; missing resource has no raw/table/empty placeholder. Two-resource subset receipt is complete only for its explicit selection.'})

    # The F77 package is read-only comparison context, never an ordinal substitute.
    facts = P / '.cache/plain-display-integration-20261101/ordinary/source/facts'
    f77_raw = client.read_file(facts / 'manifest.json', 65536)
    assert sha(f77_raw) == '050fcf93ce2cdc763d32fc9336516e25ee8791b0feb360bc811c835213712603'
    f77 = json.loads(f77_raw)
    comparison = {'package_manifest': {'path': str(facts / 'manifest.json'), 'bytes': len(f77_raw), 'sha256': sha(f77_raw)},
        'scope': 'Only three existing decoded payloads checked; no raw re-export, acquisition or full F77 closure replay.',
        'source_declaration': {k: f77['source_identity'][k] for k in ['game', 'game_patch', 'realm']},
        'tables': {}, 'join_candidate_count': 0,
        'reason': 'New IndexableSupportGems has zero rows, hence zero SupportGem occurrences. Existing SkillGems/SupportGems/BaseItemTypes ordinals/names do not establish missing Index values.'}
    for name in ['SkillGems', 'SupportGems', 'BaseItemTypes']:
        filename = f'tables/{name}.json'
        pin = f77['files'][filename]
        table = json.loads(pinned(facts / filename, pin, 5 * client.MIB))
        assert all(row['_row'] == i for i, row in enumerate(table['rows']))
        comparison['tables'][name] = {'path': str(facts / filename), **pin,
            'rows': len(table['rows']), 'physical_fields': table['physical_fields'],
            'raw_resource': table['raw_resource'],
            'raw_pin_from_existing_manifest': f77['source_identity']['raw_resources'][table['raw_resource']]}
    put(HERE / 'f77-bounded-comparison.json', comparison)

    # Bind the PoE1 guards and installed legacy physical specs to actual trusted bytes.
    installed = Path(importlib.metadata.distribution('PyPoE').locate_file('PyPoE'))
    excerpts = {}
    for relative, spans in [('poe/file/translations.py', [(2394, 2426)]),
                            ('poe/file/specification/data/poe2.py', [(1471, 1486), (23302, 23320)])]:
        raw = client.read_file(installed / relative, 4 * client.MIB)
        assert sha(raw) == manifest['decoder']['sources'][relative]
        lines = raw.decode().splitlines(keepends=True)
        excerpts[relative] = {'path': str(installed / relative), 'bytes': len(raw), 'sha256': sha(raw),
            'excerpts': [{'first_line': a, 'last_line': b, 'text': ''.join(lines[a - 1:b])} for a, b in spans]}
    assert 'if relational_reader.specification.sequel == 1:' in excerpts['poe/file/translations.py']['excerpts'][0]['text']
    put(HERE / 'community-evidence.json', {'pypoe_revision': manifest['decoder']['pypoe_revision'],
        'trusted_source_pin_sha256': manifest['decoder']['trusted_source_pin_sha256'], 'files': excerpts,
        'interpretation': 'Both handler registrations are guarded by sequel == 1; the similarly named PoE2 physical specs do not authorize a PoE2 formatter or key convention.'})

    relations = {'status': 'source-acquisition-draft', 'semantic_closure': False,
        'scoped_handler_gaps_closed': 0, 'scoped_handler_gaps_remaining': 13,
        'groups': [
            {'handler': 'display_indexable_support', 'scoped_stats': [
                'local_random_support_gem_index', 'local_random_support_gem_index_1',
                'local_random_support_gem_level', 'local_random_support_gem_level_1'],
             'table': 'IndexableSupportGems', 'physical_rows': 0,
             'Index_distribution': [], 'min_Index': None, 'max_Index': None,
             'SupportGem_nonnull_occurrences': 0, 'relation_candidates': [],
             'null_count': 0, 'zero_key_count': 0, 'duplicate_key_groups': [],
             'key_base': 'unestablished; no observed Index values',
             'limitation': 'Empty table proves no positive gem mapping. Level/stat association and PoE2 formatter semantics remain unproved.'},
            {'handler': 'affliction_reward_type', 'scoped_stats': [f'map_endgame_affliction_reward_{i}' for i in range(1, 10)],
             'table': 'AfflictionRewardTypeVisuals', 'physical_rows': 1,
             'AfflictionRewardTypes_distribution': [{'raw_key': 0, 'count': 1, 'physical_rows': [0]}],
             'null_count': 0, 'zero_key_count': 1, 'duplicate_key_groups': [],
             'relation_candidates': [{'physical_row': 0, 'raw_enum_key': 0,
                 'Id_literal': 'DeliriumRewardGeneric', 'Name_literal': 'Delirium'}],
             'enum_declaration': {'indexing': 0, 'enumerators': []},
             'key_base': 'Only signed integer 0 observed; no handler input offset or enum-order mapping inferred.',
             'limitation': 'Stat suffixes 1..9 are not assumed to be enum keys. Generic visual row does not bind any of the nine scoped descriptions.'},
        ],
        'comparison_lead': {'table': 'IndexableNonActiveSupportGems',
            'status': 'exact-declared-resource-missing', 'schema_validFor': 3,
            'applies_to_current_13_scoped_stats': False,
            'scope': 'Caller-requested comparison only; no PoE2 applicability or renamed resource inferred.'},
        'preservation': 'All decoded rows, typed columns, order, nulls/zeros, duplicates and unknown columns retained by unchanged exporter; these two tables have no array columns and no schema-unknown physical fields. Zero-row null/duplicate counts are vacuous, not values supplied for missing mappings.',
        'ownership': 'RePoE source facts only. Root owns any later PoBR interpretation, formatter, consumer implementation and validation.'}
    put(HERE / 'relation-candidates.json', relations)

    freshness = P / '.cache/postmerge-20261101/freshness-raw-2202'
    observation_raw = client.read_file(freshness / 'observation.json', 4096)
    observation = json.loads(observation_raw)
    response_pin = observation['response']
    pinned(freshness / response_pin['path'], response_pin, 4096)
    put(HERE / 'observation-boundaries.json', {'status': 'source-acquisition-draft',
        'target_declaration': {'game': 'poe2', 'game_patch': '0.5.5.5', 'realm': 'international', 'language': 'English'},
        'observed': {'fixed_https_cdn_path': 'https://patch-poe2.poecdn.com/0.5.5.5/',
            'resource_directory': 'Data/Balance/', 'language_subdirectory': None,
            'literal_Name_values': ['Delirium'], 'client_build_independently_observed': None,
            'patch_independently_certified': False, 'realm_independently_certified': False,
            'language_independently_certified': False},
        'freshness_reused_without_query': {'observation_path': str(freshness / 'observation.json'),
            'observation_sha256': sha(observation_raw), 'response_path': str(freshness / response_pin['path']),
            'response': response_pin, 'finished': observation['finished'], 'endpoint_result': observation['result']},
        'freshness_limit': 'Official endpoint version observation does not authenticate these raw resources or extend old acceptance.',
        'raw_pin_semantics': 'Observed bytes newly frozen for offline integrity; not pre-existing trusted expected raw pins.',
        'index_spelling': 'Caller literals matched by lowercased noncryptographic hash; directory spelling was not reconstructed.',
        'acceptance_extended': False, 'adopted': False})

    # Replay only the new 110 raw bytes through the unchanged generic exporter.
    command = json.loads((HERE / 'export-command.json').read_bytes())
    argv = command['argv'][:]
    argv[argv.index('--out') + 1] = str(HERE / 'candidate-replay')
    put(HERE / 'replay-command.json', {**command, 'argv': argv})
    result = subprocess.run(argv, cwd=ROOT, env={**__import__('os').environ,
        'TMPDIR': str(HERE / 'tmp'), 'PYTHONDONTWRITEBYTECODE': '1'}, capture_output=True)
    client.write_new(HERE / 'logs/replay.stdout', result.stdout)
    client.write_new(HERE / 'logs/replay.stderr', result.stderr)
    assert result.returncode == 0, result.stderr.decode()
    replay = {}
    for name in ['tables.json', 'source-lock.json', 'manifest.json']:
        raw = (HERE / 'candidate' / name).read_bytes()
        assert raw == (HERE / 'candidate-replay' / name).read_bytes()
        replay[name] = {'bytes': len(raw), 'sha256': sha(raw)}
    http = []
    for folder in sorted((HERE / 'http').iterdir()):
        request = json.loads((folder / 'request.json').read_bytes())
        response = json.loads((folder / 'response.json').read_bytes())
        reads = json.loads((folder / 'reads.json').read_bytes())
        assert response['status'] == 206 and len(reads) == 1
        body = pinned(folder / reads[0]['path'], reads[0], 4 * client.MIB)
        range_text = dict(request['headers'])['Range']
        first, last = map(int, range_text.removeprefix('bytes=').split('-'))
        assert len(body) == last - first + 1
        url = request['url']
        record_path = HERE / 'ranges/ranges' / sha(url.encode()) / f'{first}-{last}.json'
        record = json.loads(record_path.read_bytes())
        assert record['sha256'] == sha(body)
        assert (HERE / 'ranges/blobs' / (record['sha256'] + '.bin')).read_bytes() == body
        http.append({'request_folder': str(folder.relative_to(HERE)), 'url': url, 'range': range_text,
            'bytes': len(body), 'sha256': sha(body),
            'response_header_serialization_bytes': (folder / 'response-headers.eml').stat().st_size,
            'range_record': str(record_path.relative_to(HERE))})
    body_bytes = sum(r['bytes'] for r in http)
    header_bytes = sum(r['response_header_serialization_bytes'] for r in http)
    assert body_bytes == 157643 and body_bytes + header_bytes < 4 * client.MIB
    put(HERE / 'http-request-manifest.json', {'requests': http, 'body_bytes': body_bytes,
        'serialized_response_headers_bytes': header_bytes, 'body_plus_serialized_headers_bytes': body_bytes + header_bytes,
        'body_reservation_bytes_including_overflow_guards': 157649, 'cap_bytes': 4 * client.MIB,
        'wire_byte_count': 'not instrumented; serialized HTTP headers are retained, TLS/TCP overhead is not measured'})
    put(HERE / 'verification.json', {'status': 'passed-new-bounded-source-checks',
        'new_tables': 2, 'new_raw_bytes': 110, 'independent_binary_rows': True,
        'empty_table_layout_certified': False, 'pinned_three_f77_payloads_checked': True,
        'http_response_cache_body_equivalence': True, 'replay_returncode': result.returncode,
        'byte_identical_replay_files': replay,
        'checks': ['Original decoder/RECORD/uv.lock identity equals actor and original index receipt.',
            'Exact selected index records and fixed cached file-table hash checked without index decoding/network.',
            'Complete raw pins, DAT row counts, magic, Affliction signed key and UTF-16 pointers independently checked.',
            'All six requested ranges equal saved original response bodies and immutable range-cache bodies.',
            'Existing native exporter replay of only two new tables is byte-identical.'],
        'not_run': ['No compile/build, dependency install or environment sync.',
            'No full unit/check suite or OS network-denial sandbox; unchanged exporter only, existing selected-table CLI is offline by construction.',
            'No old 335MB acquisition, F77 export/full closure verification, 346-chunk decompression or descriptions bulk JSON read.',
            'No PoBR formatter/consumer/product/BD/browser tests, publication, push, PR, adoption, CURRENT/global-lock changes.',
            'No new freshness query, independent client-build/language/patch/realm certification or source approval.']})
    print(json.dumps({'replay': replay, 'http_body_bytes': body_bytes, 'http_saved_header_bytes': header_bytes,
        'raw_rows': {n: len(t['rows']) for n, t in tables.items()},
        'handler_gaps_closed': 0, 'handler_gaps_remaining': 13}, indent=2))


if __name__ == '__main__':
    main()
