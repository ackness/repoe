"""Exact declared-path lookup in already decoded, receipt-pinned warm file table.

No index download, index decompression, directory-name reconstruction, or old
resource closure replay. This is a new local hash search, not a new index receipt.
"""
import hashlib
import json
import os
from pathlib import Path
import struct
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
P = Path('/Users/claw/.t3/worktrees/pobr/design-independent-pobr-ecosystem')
ACTOR = Path('/Users/claw/.t3/worktrees/repoe/feat-native-actor-object-templates/.cache/actor-templates-20261101')
sys.path.insert(0, str(P / 'pipeline'))
import client_index as index
client = index.client
sha = client.sha256
put = lambda path, value: client.write_new(path, client.encoded(value))
NAMES = ['IndexableSupportGems', 'AfflictionRewardTypeVisuals', 'IndexableNonActiveSupportGems']


def main():
    prior_raw = (ACTOR / 'decoder-identity.json').read_bytes()
    prior = json.loads(prior_raw)
    request = json.loads((ACTOR / 'level-00-request.json').read_bytes())
    request['resources'] = [f'Data/Balance/{n}.datc64' for n in NAMES]
    put(HERE / 'request.json', request)
    index.load_request(HERE / 'request.json')
    decoder = client.ExternalDecoder('/Users/claw/codes/repoe/.venv/bin/python', '/Users/claw/codes/repoe/uv.lock', request)
    assert decoder.receipt == prior['current'], 'Decoder differs from existing receipt'
    original_receipt = Path(prior['prior_receipt_path']).read_bytes()
    assert sha(original_receipt) == prior['prior_receipt_sha256']
    assert json.loads(original_receipt)['decoder'] == decoder.receipt
    put(HERE / 'decoder-identity.json', {
        'current': decoder.receipt, 'matches_actor_and_original_index_receipt': True,
        'actor_identity': {'path': str(ACTOR / 'decoder-identity.json'), 'sha256': sha(prior_raw)},
        'original_receipt': {'path': prior['prior_receipt_path'], 'sha256': sha(original_receipt)},
        'warm_cache': prior['warm_cache'], 'tools': index.tools(),
    })
    location_raw = (ACTOR / 'level-00-diagnostic/index-locations.json').read_bytes()
    location = json.loads(location_raw)
    original_locations_raw = Path(location['prior_framing_path']).read_bytes()
    assert sha(original_locations_raw) == location['prior_framing_sha256']
    framing = location['framing']
    assert framing == json.loads(original_locations_raw)['framing']
    assert index.tools()['client_index.py'] == prior['tools_current']['client_index.py']
    chunks = {r['chunk']: r for r in framing['decoded_chunks']}
    used = {}

    class Saved:
        chunk = -1
        raw = b''

        def read(self, start, length):
            result = bytearray()
            while length:
                number, within = divmod(start, 262144)
                if number != self.chunk:
                    pin = chunks[number]
                    path = ACTOR / 'index-chunks' / f'{number:03d}.bin'
                    raw = client.read_file(path, 262144)
                    assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
                    self.raw, self.chunk = raw, number
                    used[number] = {'path': str(path), **pin}
                size = min(length, len(self.raw) - within)
                assert size > 0
                result.extend(self.raw[within:within + size])
                start += size
                length -= size
            return bytes(result)

    saved = Saved()
    seed = index.seed_from_root(framing['first_directory_hash'])
    assert seed == framing['hash_seed']
    wanted = {index.hash64(n.lower().encode('ascii'), seed): n for n in request['resources']}
    assert len(wanted) == 3
    encoded = {struct.pack('<Q', h): n for h, n in wanted.items()}
    found = {}
    table_sha = hashlib.sha256()
    # Search only the fixed file-table extent. No directory inventory or strings.
    for first in range(0, framing['file_count'], 50000):
        count = min(50000, framing['file_count'] - first)
        at = framing['file_table_offset'] + first * 20
        raw = saved.read(at, count * 20)
        table_sha.update(raw)
        for needle, name in encoded.items():
            offset = raw.find(needle)
            while offset != -1:
                if offset % 20 == 0:
                    assert name not in found, 'Duplicate selected path hash'
                    record_raw = raw[offset:offset + 20]
                    h, bundle, position, length = struct.unpack('<QIII', record_raw)
                    found[name] = {'record_index': first + offset // 20, 'path_hash': h,
                        'path_hash_hex': f'{h:016x}', 'bundle_index': bundle,
                        'offset': position, 'length': length,
                        'file_record_byte_offset': at + offset,
                        'file_record_hex': record_raw.hex()}
                offset = raw.find(needle, offset + 1)
    assert table_sha.hexdigest() == framing['file_table_sha256']
    # Parse bundle metadata only when a selected physical record exists.
    if found:
        assert struct.unpack('<I', saved.read(0, 4))[0] == framing['bundle_count']
        cursor = 4
        for number in range(framing['bundle_count']):
            start = cursor
            length = struct.unpack('<I', saved.read(cursor, 4))[0]
            assert 1 <= length <= 256
            raw = saved.read(cursor, length + 8)
            name = raw[4:4 + length].decode('ascii')
            size = struct.unpack('<I', raw[-4:])[0]
            for record in found.values():
                if record['bundle_index'] == number:
                    assert record['offset'] + record['length'] <= size
                    record.update(bundle_name=name, bundle_raw_bytes=size,
                        bundle_record_byte_offset=start, bundle_record_hex=raw.hex())
            cursor += length + 8
        assert cursor + 4 == framing['file_table_offset']
    missing = [n for n in request['resources'] if n not in found]
    schema_raw = (ROOT / 'schema/poe2.json').read_bytes()
    schema = json.loads(schema_raw)
    put(HERE / 'schema-leads.json', {'schema_source': json.loads((ROOT / 'schema/source.json').read_bytes()),
        'schema_sha256': sha(schema_raw),
        'tables': [t for t in schema['tables'] if t['name'] in NAMES],
        'enumerations': [e for e in schema['enumerations'] if e['name'] == 'AfflictionRewardTypes'],
        'semantics': 'Schema hints only; enum enumerator order is not inferred as raw key.'})
    proof = {'schema': 'description-relation-exact-index-diagnostic/v1',
        'status': 'complete-exact-hash-search' if not missing else 'incomplete-discovery-diagnostic',
        'production_ready': False, 'game_patch_declaration': '0.5.5.5', 'realm_declaration': 'international',
        'index_url': location['index_url'], 'request_sha256': sha((HERE / 'request.json').read_bytes()),
        'matched': found, 'missing': missing,
        'all_or_nothing_reader_would_fail': bool(missing),
        'reader_failure': 'Paths not found in the selected index: ' + ', '.join(missing) if missing else None,
        'file_table': {k: v for k, v in framing.items() if k != 'decoded_chunks'},
        'prior_location_evidence': [{'path': str(ACTOR / 'level-00-diagnostic/index-locations.json'), 'sha256': sha(location_raw)},
            {'path': location['prior_framing_path'], 'sha256': sha(original_locations_raw)}],
        'method': 'Exact lowercased caller-path Murmur64A search in receipt-pinned cached file table; no new index decode/download.',
        'path_spelling_authority': 'caller literal; case-insensitive noncryptographic hash match, no directory spelling reconstruction',
        'network': {'requests': 0, 'body_bytes': 0}, 'decoded_index_chunks_this_run': 0,
        'cached_chunk_pins_used': list(used.values()), 'driver_sha256': sha(Path(__file__).read_bytes()),
        'limitations': ['Hash match is not independent client patch/realm authentication.',
            'Absence applies only to these exact declared paths in this fixed index; no renamed-path or directory guessing.',
            'No handler semantics, key base, language certification or source acceptance follows from location.']}
    put(HERE / 'index-locations.json', proof)
    if found:
        selection = {'schema': index.draft.SELECTION_SCHEMA, 'game': 'poe2', 'realm': 'international',
            'game_patch': '0.5.5.5', 'base_url': 'https://patch-poe2.poecdn.com/0.5.5.5/',
            'decoder': request['decoder'], 'location_evidence': [{'id': 'exact-index-hash-search',
                'reference': str(HERE / 'index-locations.json'), 'sha256': sha((HERE / 'index-locations.json').read_bytes())}],
            'resources': {}}
        for name in request['resources']:
            if name in found:
                r = found[name]
                selection['resources'][name] = {'bundle_url': selection['base_url'] + 'Bundles2/' + r['bundle_name'] + '.bundle.bin',
                    'uncompressed_offset': r['offset'], 'uncompressed_length': r['length'],
                    'location_evidence': ['exact-index-hash-search']}
        put(HERE / 'selection.json', selection)
        index.draft.load_selection(HERE / 'selection.json')
    print(json.dumps({'matched': found, 'missing': missing, 'network_bytes': 0, 'index_chunks_decoded': 0}, indent=2))


if __name__ == '__main__':
    os.environ['TMPDIR'] = str(HERE / 'tmp')
    main()
